package interfaz;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import org.farng.mp3.id3.AbstractID3v2;
import org.tritonus.share.sampled.file.TAudioFileFormat;
import javazoom.jlgui.basicplayer.BasicController;
import javazoom.jlgui.basicplayer.BasicPlayerEvent;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import javazoom.jlgui.basicplayer.BasicPlayerListener;

public class LD
{
    public class Metadatos {

        AbstractID3v2 id3;
        String artist;
        String song;
        String album;
        String genre;
        int duration;
        int songSize;

        public void Metadatos(String ruta) throws IOException, TagException { //Constructor de la clase Metadatos
       
            MP3File mp3 = new MP3File(ruta); //Crea un nuevo objeto llamando una clase de la librerÃ­a
            id3 = mp3.getID3v2Tag(); //Usa el ojeto creado para obener los metadatos de la canciÃ³n dada en la ruta
//            Metadatos d = new Metadatos();//Crea un nuevo objeto de la clase Metadatos
 //           d.Metadatos(id3); //Inicia el constructor de la clase Metadatos con el objeto creado anteriormene            
        }

        public void getArtist() { //MÃ©todo para obtener el artista de la canciÃ³n
            this.artist = id3.getLeadArtist();
            System.out.println("Artista: " + this.artist); //Imprime el artista de la canciÃ³n
        }

        public void getSong() { //MÃ©todo para obtener el nombre de la canciÃ³n
            this.song = id3.getSongTitle();
            System.out.println("CanciÃ³n: " + song); //Imprime el nombre de la canciÃ³n
        }

        public void getAlbum() { //MÃ©todo para obtener el Ã¡lbum de la canciÃ³n
            this.album = id3.getAlbumTitle();
            System.out.println("Ã�lbum: " + album); //Imprime el Ã¡lbum de la canciÃ³n
        }

        public void getGenre() { //MÃ©todo para obtener el gÃ©nero de la canciÃ³n
            this.genre = id3.getSongGenre();
            System.out.println("GÃ©nero: " + genre); //Imprime el gÃ©nero de la canciÃ³n
        }

        public void getSize() { //MÃ©todo para obtener el tamaÃ±o de la canciÃ³n
            this.songSize = id3.getSize();
            System.out.println("TamaÃ±o: " + songSize); //Imprime el tamaÃ±o de la canciÃ³n
        }
        private void getDuration(String dato) throws UnsupportedAudioFileException, IOException {
            File file = new File(dato);
            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
            if (fileFormat instanceof TAudioFileFormat) {
                Map<?, ?> properties = ((TAudioFileFormat) fileFormat).properties();
                String key = "duration";
                Long microseconds = (Long) properties.get(key);
                int mili = (int) (microseconds / 1000);
                int sec = (mili / 1000) % 60;
                int min = (mili / 1000) / 60;
                System.out.println("Duracion: " + min + ":" + sec);
            } else {
                throw new UnsupportedAudioFileException();
            }

        }

        public void setArtist(String artista) { //MÃ©todo para modificar el artista de la canciÃ³n
            id3.setLeadArtist(artista);
        }

        public void setSong(String songTitle) { //MÃ©todo para modificar el nombre de la canciÃ³n
            id3.setSongTitle(songTitle);
        }

        public void setAlbum(String songAlbum) { //MÃ©todo para modificar el Ã¡lbum de la canciÃ³n
            id3.setAlbumTitle(songAlbum);
        }

        public void setGenge(String songGenre) { //MÃ©todo para modificar el gÃ©nero de la canciÃ³n
            id3.setSongGenre(songGenre);
        }
    }
    public abstract class Reproductor implements BasicPlayerListener 
{
    private final BasicPlayer basicPlayer;
    private double bytesLength;

    /**
     *
     */
    public Reproductor() throws BasicPlayerException 
    {
        basicPlayer = new BasicPlayer();
        basicPlayer.addBasicPlayerListener(this);
        basicPlayer.play();
    }

    public void play() 
    {
        try {
        basicPlayer.play();
        }
        catch (BasicPlayerException e) 
        {
        }
    }

    public void stop() 
    {
        try 
        {
            basicPlayer.stop();
        } 
        catch (BasicPlayerException e) 
        {
        }
    }

    public void pause() 
    {
        try 
        {
            basicPlayer.pause();
        } 
        catch (BasicPlayerException e) 
        {
        }
    }

    public void resume() 
    {
        try 
        {
            basicPlayer.resume();
        } 
        catch (BasicPlayerException e) 
        {
        }
    }

    public void loadFile(String ruta) throws BasicPlayerException 
    {
        basicPlayer.open(new File(ruta));
    }

/**
* Necesario por implementar BasicPlayerListener. Es ejecutado una vez se
* carga un fichero. En este caso, obtiene el tamaÃ±o en bytes del fichero.
     * @param arg0
     * @param arg1
*/

    public void opened(Object arg0, Map arg1) 
    {
        if (arg1.containsKey("audio.length.bytes")) 
        {
            bytesLength = Double.parseDouble(arg1.get("audio.length.bytes").toString());
        }
    }

/**
* Necesario por implementar BasicPlayerListener. SegÃºn la documentaciÃ³n,
* este mÃ©todo es llamado varias veces por segundo para informar del
* progreso en la reproducciÃ³n.
     * @param bytesread
     * @param microseconds
     * @param pcmdata
     * @param properties
*/

    public void progress(int bytesread, long microseconds, byte[] pcmdata,Map properties) 
    {
        float progressUpdate = (float) (bytesread * 1.0f / bytesLength * 1.0f);
        int progressNow = (int) (bytesLength * progressUpdate);
        // Descomentando la siguiente lÃ­nea se mosrtarÃ­a el progreso
        // System.out.println(" -> " + progressNow);
    }

    public void setController(BasicController arg0) 
    {
        // TODO Auto-generated method stub

    }


    public void stateUpdated(BasicPlayerEvent arg0) 
    {
        // TODO Auto-generated method stub

    }
}

    class Nodo 
    {
        String info;
        Nodo ant,sig;
    }
    
    Metadatos metda;
    Reproductor repro;
    private Nodo raiz;
    private Nodo actual;
    
    public LD ()throws BasicPlayerException
    {
        this.metda = new Metadatos ();
        this.repro = new Reproductor() {};
        raiz=null;
        actual=raiz;
    }
              
    
    public void insertarUltimo(String cancion) throws IOException, TagException, UnsupportedAudioFileException {
        Nodo nuevo=new Nodo();
        nuevo.info=cancion;
        if (raiz==null) {
            nuevo.sig=nuevo;
            nuevo.ant=nuevo;            
            raiz=nuevo;
            actual=raiz;
            imprimir();
        } else {
            Nodo ultimo=raiz.ant;
            nuevo.sig=raiz;
            nuevo.ant=ultimo;
            raiz.ant=nuevo;
            ultimo.sig=nuevo;
            imprimir();
        }
    }    
    
    public boolean vacia ()
    {
        if (this.raiz == null)
            return true;
        else
            return false;
    }
    
    public void imprimir () throws IOException, TagException, UnsupportedAudioFileException
    {
        if (!vacia()) 
        {
            int i=1;
            Nodo reco=this.raiz;
            do {
                String dato = reco.info;
                this.metda.Metadatos(dato);
                metda.getAlbum();
                metda.getArtist();
                metda.getGenre();
                metda.getSong();
                metda.getDuration(dato);
                reco = reco.sig;
                ++i;
            } while (reco!=this.raiz);
            System.out.println();
        }    
    }
    
    public void siguiente()
    {
        if (this.actual==null)
        {
            this.actual= this.raiz;
            this.actual= this.actual.sig;
        } 
        else
        {
            this.actual= this.actual.sig;
        }
    }
    
        public void anterior()
    {
        if (this.actual==null)
        {
            this.actual= this.raiz;
            this.actual= this.actual.ant;
        } 
        else
        {
            this.actual= this.actual.ant;
        }
    }
    
    public int cantidad ()
    {
        int cant = 0;
        if (!vacia()) {
            Nodo reco=this.raiz;
            do {
                cant++;
                reco = reco.sig;                
            } while (reco!=this.raiz);
        }    
        return cant;
    }
    
    public void borrar (int pos) throws IOException, TagException, UnsupportedAudioFileException
    {
        if (pos <= cantidad ())    {
            if (pos == 1) {
                if (cantidad()==1) {
                    raiz=null;
                    this.actual=raiz;
                    imprimir ();
                } else {
                    Nodo ultimo=raiz.ant;    
                    raiz = raiz.sig;
                    ultimo.sig=raiz;
                    raiz.ant=ultimo;
                    this.actual= raiz;
                    imprimir ();
                } 
            } else {
                Nodo reco = raiz;
                for (int f = 1 ; f <= pos - 1 ; f++)
                    reco = reco.sig;
                Nodo anterior = reco.ant;
                reco=reco.sig;
                anterior.sig=reco;
                reco.ant=anterior;
            }
        }
    }
    public void reproducir() throws BasicPlayerException
    {
        String dato = this.actual.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void reproducirSiguente() throws BasicPlayerException
    {
        repro.stop();
        String dato = this.actual.sig.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void reproducirAnterior() throws BasicPlayerException
    {
        repro.stop();
        String dato = this.actual.ant.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void pausa() 
    {
        repro.pause();
    }
    public void detener()
    {
        repro.stop();
        actual=raiz;
    }

    public static void main(String[] args) throws BasicPlayerException, IOException, TagException, UnsupportedAudioFileException  
    {
        LD n = new LD();
        n.insertarUltimo("C:\\Users\\gollo\\Music\\2011 - Get Your Heart On!\\04 - Astronaut.mp3");
        
        n.reproducir();
       
        
        
        
        
            
            
        
    }
    
}


