/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package interfaz;

import interfaz.IntTP1.LD.Reproductor;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JCheckBox;//Librería para la selección de la imagen
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;
import javazoom.jlgui.basicplayer.BasicController;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerEvent;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import javazoom.jlgui.basicplayer.BasicPlayerListener;
import org.farng.mp3.MP3File;
import org.farng.mp3.TagException;
import org.farng.mp3.id3.AbstractID3v2;
import org.tritonus.share.sampled.file.TAudioFileFormat;


public class IntTP1 extends javax.swing.JFrame {
    
    LD reproducir;
    
    private FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivo de cancion","MP3");
    String rutacancion;//creamos la variable rutacancion
    
    
    public IntTP1() throws BasicPlayerException {
        this.reproducir = new LD();
        
        
        initComponents();
        rutacancion="";
    }
   

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jList3 = new javax.swing.JList();
        jFrame1 = new javax.swing.JFrame();
        jDialog1 = new javax.swing.JDialog();
        jFileChooser1 = new javax.swing.JFileChooser();
        jCheckBox1 = new javax.swing.JCheckBox();
        jFrame2 = new javax.swing.JFrame();
        jFrame3 = new javax.swing.JFrame();
        jFrame4 = new javax.swing.JFrame();
        jFrame5 = new javax.swing.JFrame();
        jPanel1 = new javax.swing.JPanel();
        BotonAnterior = new javax.swing.JButton();
        BotonReproducir = new javax.swing.JButton();
        BotonSiguiente = new javax.swing.JButton();
        BotonDetener = new javax.swing.JButton();
        BotonPausar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BuscarCancion = new javax.swing.JCheckBox();
        BuscarGenero = new javax.swing.JCheckBox();
        BuscarAlbum = new javax.swing.JCheckBox();
        BuscarArtista = new javax.swing.JCheckBox();
        BusquedaAvanzada = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        ListaCanciones = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        ListaAlbum = new javax.swing.JList();
        jScrollPane5 = new javax.swing.JScrollPane();
        ListaDuracion = new javax.swing.JList();
        jScrollPane6 = new javax.swing.JScrollPane();
        ListaGenero = new javax.swing.JList();
        jScrollPane7 = new javax.swing.JScrollPane();
        ListaArtistas = new javax.swing.JList();
        BotonAgregar = new javax.swing.JButton();
        BotonEliminar = new javax.swing.JButton();
        BotonModificar = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();

        jTextArea1.setBackground(new java.awt.Color(0, 102, 153));
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jTextField1.setBackground(new java.awt.Color(0, 102, 153));
        jTextField1.setText("Canción");

        jList3.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane4.setViewportView(jList3);

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jCheckBox1.setText("jCheckBox1");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame3Layout.setVerticalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame4Layout = new javax.swing.GroupLayout(jFrame4.getContentPane());
        jFrame4.getContentPane().setLayout(jFrame4Layout);
        jFrame4Layout.setHorizontalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame4Layout.setVerticalGroup(
            jFrame4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame5Layout = new javax.swing.GroupLayout(jFrame5.getContentPane());
        jFrame5.getContentPane().setLayout(jFrame5Layout);
        jFrame5Layout.setHorizontalGroup(
            jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame5Layout.setVerticalGroup(
            jFrame5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Little Devil\n");

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setForeground(new java.awt.Color(0, 153, 153));

        BotonAnterior.setIcon(new javax.swing.ImageIcon("C:\\Users\\gollo\\Desktop\\anterior.png")); // NOI18N
        BotonAnterior.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAnteriorActionPerformed(evt);
            }
        });

        BotonReproducir.setIcon(new javax.swing.ImageIcon("C:\\Users\\gollo\\Desktop\\diablo.gif")); // NOI18N
        BotonReproducir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonReproducirActionPerformed(evt);
            }
        });

        BotonSiguiente.setIcon(new javax.swing.ImageIcon("C:\\Users\\gollo\\Desktop\\sig2.jpg")); // NOI18N
        BotonSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonSiguienteActionPerformed(evt);
            }
        });

        BotonDetener.setText("Volver inicio");
        BotonDetener.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonDetenerActionPerformed(evt);
            }
        });

        BotonPausar.setText("Detener");
        BotonPausar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonPausarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(0, 102, 153));

        jLabel1.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel1.setText("Canción");

        jLabel2.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel2.setText("Artista");

        jLabel3.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel3.setText("Álbum");

        jLabel4.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel4.setText("Género");

        jLabel5.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel5.setText("Duración");

        jLabel6.setFont(new java.awt.Font("Maiandra GD", 0, 18)); // NOI18N
        jLabel6.setText("Buscar");

        BuscarCancion.setBackground(new java.awt.Color(0, 102, 153));
        BuscarCancion.setText("Canción");
        BuscarCancion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarCancionActionPerformed(evt);
            }
        });

        BuscarGenero.setBackground(new java.awt.Color(0, 102, 153));
        BuscarGenero.setText("Género");

        BuscarAlbum.setBackground(new java.awt.Color(0, 102, 153));
        BuscarAlbum.setText("Álbum");

        BuscarArtista.setBackground(new java.awt.Color(0, 102, 153));
        BuscarArtista.setText("Artista");
        BuscarArtista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarArtistaActionPerformed(evt);
            }
        });

        BusquedaAvanzada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BusquedaAvanzadaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(146, 146, 146)
                .addComponent(jLabel2)
                .addGap(150, 150, 150)
                .addComponent(jLabel3)
                .addGap(138, 138, 138)
                .addComponent(jLabel4)
                .addGap(108, 108, 108)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 119, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(BuscarCancion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BuscarArtista)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BuscarAlbum)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BuscarGenero)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(BusquedaAvanzada, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(109, 109, 109))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addGap(226, 226, 226))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(BuscarCancion)
                            .addComponent(BuscarArtista)
                            .addComponent(BuscarAlbum)
                            .addComponent(BuscarGenero))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(BusquedaAvanzada, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        ListaCanciones.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        ListaCanciones.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                ListaCancionesComponentAdded(evt);
            }
        });
        ListaCanciones.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaCancionesValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(ListaCanciones);

        ListaAlbum.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        ListaAlbum.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaAlbumValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(ListaAlbum);

        ListaDuracion.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        ListaDuracion.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaDuracionValueChanged(evt);
            }
        });
        jScrollPane5.setViewportView(ListaDuracion);

        ListaGenero.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        ListaGenero.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaGeneroValueChanged(evt);
            }
        });
        jScrollPane6.setViewportView(ListaGenero);

        ListaArtistas.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        ListaArtistas.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                ListaArtistasValueChanged(evt);
            }
        });
        jScrollPane7.setViewportView(ListaArtistas);

        BotonAgregar.setIcon(new javax.swing.ImageIcon("C:\\Users\\gollo\\Desktop\\agregar.jpg")); // NOI18N
        BotonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAgregarActionPerformed(evt);
            }
        });

        BotonEliminar.setIcon(new javax.swing.ImageIcon("C:\\Users\\gollo\\Desktop\\borrar.jpg")); // NOI18N
        BotonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonEliminarActionPerformed(evt);
            }
        });

        BotonModificar.setText("Modificar");
        BotonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonModificarActionPerformed(evt);
            }
        });

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(16, 16, 16)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(24, 24, 24)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(139, 139, 139)
                                .addComponent(BotonPausar)
                                .addGap(18, 18, 18)
                                .addComponent(BotonModificar)
                                .addGap(18, 18, 18)
                                .addComponent(BotonDetener)
                                .addGap(30, 30, 30)
                                .addComponent(BotonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(BotonAnterior, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(BotonReproducir)
                                .addGap(18, 18, 18)
                                .addComponent(BotonSiguiente, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(BotonEliminar)
                                .addGap(29, 29, 29)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotonReproducir)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BotonAgregar, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(BotonAnterior, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(BotonModificar)
                                        .addComponent(BotonDetener)
                                        .addComponent(BotonPausar))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BotonSiguiente)
                            .addComponent(BotonEliminar))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane7)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE)
                    .addComponent(jScrollPane6)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 334, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAgregarActionPerformed
        //Creamos un objeto de JFileChooser
        JFileChooser dlg = new JFileChooser();
        //De este objeto llamamos al objeto setFileFilter
        dlg.setFileFilter(filter);
        //Se va a abrir la ventana de dialogo para elegir la cancion
        int opcion= dlg.showOpenDialog(this);
        //Si hacemos click en abrir 
        if(opcion==JFileChooser.APPROVE_OPTION){
            //Obtener nombre del archivo que hemos seleccionado
            String file = dlg.getSelectedFile().getPath();//path es para obtener el nombre
            //Obtener la direccion donde se guardara la cancion
            String archivo = dlg.getSelectedFile().toString();
            
            try {
                reproducir.insertarUltimo(archivo);
            } catch (IOException ex) {
                Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (TagException ex) {
                Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedAudioFileException ex) {
                Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
    }//GEN-LAST:event_BotonAgregarActionPerformed

    private void BotonAnteriorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAnteriorActionPerformed
        try {
            reproducir.reproducirAnterior();
        } catch (BasicPlayerException ex) {
            Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BotonAnteriorActionPerformed

    private void BotonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonModificarActionPerformed
        
        
        
        
        
        
        
    }//GEN-LAST:event_BotonModificarActionPerformed

    private void BuscarCancionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarCancionActionPerformed
    }//GEN-LAST:event_BuscarCancionActionPerformed

    private void BuscarArtistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarArtistaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BuscarArtistaActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void BotonReproducirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonReproducirActionPerformed
        
        
        try {
            reproducir.reproducir();
        } catch (BasicPlayerException ex) {
            Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
    }//GEN-LAST:event_BotonReproducirActionPerformed

    private void BotonDetenerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonDetenerActionPerformed
        reproducir.detener();
    }//GEN-LAST:event_BotonDetenerActionPerformed

    private void BotonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonEliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BotonEliminarActionPerformed

    private void BotonPausarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonPausarActionPerformed
        try {
            reproducir.pausa();
        } catch (BasicPlayerException ex) {
            Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BotonPausarActionPerformed

    private void BotonSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonSiguienteActionPerformed
        
        try {
            reproducir.reproducirSiguente();
        } catch (BasicPlayerException ex) {
            Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BotonSiguienteActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void ListaCancionesValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaCancionesValueChanged
        
        ;
    }//GEN-LAST:event_ListaCancionesValueChanged

    private void ListaArtistasValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaArtistasValueChanged
        
    }//GEN-LAST:event_ListaArtistasValueChanged

    private void ListaAlbumValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaAlbumValueChanged
        
    }//GEN-LAST:event_ListaAlbumValueChanged

    private void ListaGeneroValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaGeneroValueChanged
        
    }//GEN-LAST:event_ListaGeneroValueChanged

    private void ListaDuracionValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_ListaDuracionValueChanged
        
    }//GEN-LAST:event_ListaDuracionValueChanged

    private void BusquedaAvanzadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BusquedaAvanzadaActionPerformed
        
    }//GEN-LAST:event_BusquedaAvanzadaActionPerformed

    private void ListaCancionesComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_ListaCancionesComponentAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_ListaCancionesComponentAdded

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IntTP1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IntTP1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IntTP1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IntTP1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new IntTP1().setVisible(true);
                } catch (BasicPlayerException ex) {
                    Logger.getLogger(IntTP1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonAgregar;
    private javax.swing.JButton BotonAnterior;
    private javax.swing.JButton BotonDetener;
    private javax.swing.JButton BotonEliminar;
    private javax.swing.JButton BotonModificar;
    private javax.swing.JButton BotonPausar;
    private javax.swing.JButton BotonReproducir;
    private javax.swing.JButton BotonSiguiente;
    private javax.swing.JCheckBox BuscarAlbum;
    private javax.swing.JCheckBox BuscarArtista;
    private javax.swing.JCheckBox BuscarCancion;
    private javax.swing.JCheckBox BuscarGenero;
    private javax.swing.JTextField BusquedaAvanzada;
    private javax.swing.JList ListaAlbum;
    private javax.swing.JList ListaArtistas;
    private javax.swing.JList ListaCanciones;
    private javax.swing.JList ListaDuracion;
    private javax.swing.JList ListaGenero;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JFrame jFrame4;
    private javax.swing.JFrame jFrame5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JList jList3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables

public class LD
{
    public class Metadatos {

        AbstractID3v2 id3;
        String artist;
        String song;
        String album;
        String genre;
        int duration;
        int songSize;

        public void Metadatos(String ruta) throws IOException, TagException { //Constructor de la clase Metadatos
       
            MP3File mp3 = new MP3File(ruta); //Crea un nuevo objeto llamando una clase de la librerÃ­a
            id3 = mp3.getID3v2Tag(); //Usa el ojeto creado para obener los metadatos de la canciÃ³n dada en la ruta
//            Metadatos d = new Metadatos();//Crea un nuevo objeto de la clase Metadatos
 //           d.Metadatos(id3); //Inicia el constructor de la clase Metadatos con el objeto creado anteriormene            
        }

        public String getArtist() { //MÃ©todo para obtener el artista de la canciÃ³n
            this.artist = id3.getLeadArtist();
            return this.artist; //Imprime el artista de la canciÃ³n
        }

        public void getSong() { //MÃ©todo para obtener el nombre de la canciÃ³n
            this.song = id3.getSongTitle();
            System.out.println(song); //Imprime el nombre de la canciÃ³n
        }

        public String getAlbum() { //MÃ©todo para obtener el Ã¡lbum de la canciÃ³n
            this.album = id3.getAlbumTitle();
            return album; //Imprime el Ã¡lbum de la canciÃ³n
        }

        public String getGenre() { //MÃ©todo para obtener el gÃ©nero de la canciÃ³n
            this.genre = id3.getSongGenre();
            return genre; //Imprime el gÃ©nero de la canciÃ³n
        }

        
        private String getDuration(String dato) throws UnsupportedAudioFileException, IOException {
            File file = new File(dato);
            AudioFileFormat fileFormat = AudioSystem.getAudioFileFormat(file);
            if (fileFormat instanceof TAudioFileFormat) {
                Map<?, ?> properties = ((TAudioFileFormat) fileFormat).properties();
                String key = "duration";
                Long microseconds = (Long) properties.get(key);
                int mili = (int) (microseconds / 1000);
                int sec = (mili / 1000) % 60;
                int min = (mili / 1000) / 60;
                return min + ":" + sec;
            } else {
                throw new UnsupportedAudioFileException();
            }

        }

        public void setArtist(String artista) { //MÃ©todo para modificar el artista de la canciÃ³n
            id3.setLeadArtist(artista);
        }

        public void setSong(String songTitle) { //MÃ©todo para modificar el nombre de la canciÃ³n
            id3.setSongTitle(songTitle);
        }

        public void setAlbum(String songAlbum) { //MÃ©todo para modificar el Ã¡lbum de la canciÃ³n
            id3.setAlbumTitle(songAlbum);
        }

        public void setGenge(String songGenre) { //MÃ©todo para modificar el gÃ©nero de la canciÃ³n
            id3.setSongGenre(songGenre);
        }
    }
    public abstract class Reproductor implements BasicPlayerListener 
{
    private final BasicPlayer basicPlayer;
    private double bytesLength;

    /**
     *
     */
    public Reproductor() throws BasicPlayerException 
    {
        basicPlayer = new BasicPlayer();
        basicPlayer.addBasicPlayerListener((BasicPlayerListener) this);
        basicPlayer.play();
    }

    public void play() 
    {
        try {
        basicPlayer.play();
        }
        catch (BasicPlayerException e) 
        {
        }
    }

    public void stop() 
    {
        try 
        {
            basicPlayer.stop();
        } 
        catch (BasicPlayerException e) 
        {
        }
    }

    public void pause() throws BasicPlayerException 
    {
        basicPlayer.pause();
    }

    public void resume() throws BasicPlayerException 
    {
        basicPlayer.resume();
    }

    public void loadFile(String ruta) throws BasicPlayerException 
    {
        basicPlayer.open(new File(ruta));
    }

/**
* Necesario por implementar BasicPlayerListener. Es ejecutado una vez se
* carga un fichero. En este caso, obtiene el tamaÃ±o en bytes del fichero.
     * @param arg0
     * @param arg1
*/

    public void opened(Object arg0, Map arg1) 
    {
        if (arg1.containsKey("audio.length.bytes")) 
        {
            bytesLength = Double.parseDouble(arg1.get("audio.length.bytes").toString());
        }
    }

/**
* Necesario por implementar BasicPlayerListener. SegÃºn la documentaciÃ³n,
* este mÃ©todo es llamado varias veces por segundo para informar del
* progreso en la reproducciÃ³n.
     * @param bytesread
     * @param microseconds
     * @param pcmdata
     * @param properties
*/

    public void progress(int bytesread, long microseconds, byte[] pcmdata,Map properties) 
    {
        float progressUpdate = (float) (bytesread * 1.0f / bytesLength * 1.0f);
        int progressNow = (int) (bytesLength * progressUpdate);
        // Descomentando la siguiente lÃ­nea se mosrtarÃ­a el progreso
        // System.out.println(" -> " + progressNow);
    }

    public void setController(BasicController arg0) 
    {
        // TODO Auto-generated method stub

    }


    public void stateUpdated(BasicPlayerEvent arg0) 
    {
        // TODO Auto-generated method stub

    }
    }

    class Nodo 
    {
        String info;
        Nodo ant,sig;
    }
    
    Metadatos metda;
    Reproductor repro;
    private Nodo raiz;
    private Nodo actual;
    
    public LD ()throws BasicPlayerException
    {
        this.metda = new Metadatos ();
        this.repro = new Reproductor() {};
        raiz=null;
        actual=raiz;
    }
    
            
    
    public void insertarUltimo(String cancion) throws IOException, TagException, UnsupportedAudioFileException {
        Nodo nuevo=new Nodo();
        nuevo.info=cancion;
        if (raiz==null) {
            nuevo.sig=nuevo;
            nuevo.ant=nuevo;            
            raiz=nuevo;
            actual=raiz;
            imprimir(1);
            imprimir(2);
            imprimir(3);
            imprimir(4);
        } else {
            Nodo ultimo=raiz.ant;
            nuevo.sig=raiz;
            nuevo.ant=ultimo;
            raiz.ant=nuevo;
            ultimo.sig=nuevo;
            imprimir(1);
            imprimir(2);
            imprimir(3);
            imprimir(4);
        }
    }    
    
    public boolean vacia ()
    {
        if (this.raiz == null)
            return true;
        else
            return false;
    }
    
    public void imprimir (int e) throws IOException, TagException, UnsupportedAudioFileException
    {
        if (!vacia()) 
        {
            int i=1;
            Nodo reco=this.raiz;
            do {
                String dato = reco.info;
                this.metda.Metadatos(dato);
                switch(e){
                    case 1:
                metda.getAlbum();
                break;
                    case 2:
                metda.getArtist();
                break;
                    case 3:
                metda.getGenre();
                break;
                    case 4:
                metda.getSong();
                break;
                    case 5:
                metda.getDuration(dato);
                break;
                }
                reco = reco.sig;
                ++i;
            } while (reco!=this.raiz);
            System.out.println();
        }    
    }
    
    public void siguiente()
    {
        if (this.actual==null)
        {
            this.actual= this.raiz;
            this.actual= this.actual.sig;
        } 
        else
        {
            this.actual= this.actual.sig;
        }
    }
    
        public void anterior()
    {
        if (this.actual==null)
        {
            this.actual= this.raiz;
            this.actual= this.actual.ant;
        } 
        else
        {
            this.actual= this.actual.ant;
        }
    }
    
    public int cantidad ()
    {
        int cant = 0;
        if (!vacia()) {
            Nodo reco=this.raiz;
            do {
                cant++;
                reco = reco.sig;                
            } while (reco!=this.raiz);
        }    
        return cant;
    }
    
    public void borrar (int pos) throws IOException, TagException, UnsupportedAudioFileException
    {
        if (pos <= cantidad ())    {
            if (pos == 1) {
                if (cantidad()==1) {
                    raiz=null;
                    this.actual=raiz;
                    imprimir(1);
                    imprimir(2);
                    imprimir(3);
                    imprimir(4);
                } else {
                    Nodo ultimo=raiz.ant;    
                    raiz = raiz.sig;
                    ultimo.sig=raiz;
                    raiz.ant=ultimo;
                    this.actual= raiz;
                    imprimir(1);
                    imprimir(2);
                    imprimir(3);
                    imprimir(4);
                } 
            } else {
                Nodo reco = raiz;
                for (int f = 1 ; f <= pos - 1 ; f++)
                    reco = reco.sig;
                Nodo anterior = reco.ant;
                reco=reco.sig;
                anterior.sig=reco;
                reco.ant=anterior;
            }
        }
    }
    public void reproducir() throws BasicPlayerException
    {
        String dato = this.actual.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void reproducirSiguente() throws BasicPlayerException
    {
        repro.stop();
        this.actual=this.actual.sig;
        String dato = this.actual.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void reproducirAnterior() throws BasicPlayerException
    {
        repro.stop();
        this.actual=this.actual.ant;
        String dato = this.actual.info;
        repro.loadFile(dato);
        repro.play();
        
    }
    public void pausa() throws BasicPlayerException 
    {
        repro.pause();
    }
    public void detener()
    {
        repro.stop();
        actual=raiz;
    }
       
        
        
        
        
            
            
        
    }
    
}





